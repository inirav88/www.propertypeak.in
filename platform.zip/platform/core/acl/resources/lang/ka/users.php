<?php

return [
    'assigned_role' => 'როლის მინიჭება',
    'role' => 'როლი',
    'cancel_btn' => 'გაუქმება',
    'users' => 'მომხმარებლები',
];
